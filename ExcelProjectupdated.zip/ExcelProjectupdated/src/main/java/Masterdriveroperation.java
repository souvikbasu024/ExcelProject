import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Masterdriveroperation {
    public static void main(String[] args) {
        try {
            // Load the Excel file
            FileInputStream fileInputStream = new FileInputStream("C:\\Users\\dell\\Desktop\\New folder\\ACT_MasterDriver.xlsx");
            Workbook workbook = new XSSFWorkbook(fileInputStream);
            XSSFSheet sheet = (XSSFSheet) workbook.getSheetAt(0); // Replace 0 with the index of your desired sheet

            // Define the search value
            String searchValue = "GTD_HR_01";

            // Define the number of times to copy the row
            int copyCount = 16; // Change this value as needed

            // Loop through the rows
            for (int rowNum = sheet.getFirstRowNum(); rowNum <= sheet.getLastRowNum(); rowNum++) {
                Row row = sheet.getRow(rowNum);

                if (row != null) {
                    Cell cell = row.getCell(0); // Replace 0 with the column index where you want to search

                    if (cell != null && cell.getCellType() == CellType.STRING) {
                        String cellValue = cell.getStringCellValue();

                        if (cellValue.equals(searchValue)) {
                            // Copy and insert the row multiple times
                            for (int i = 0; i < copyCount; i++) {
                                sheet.shiftRows(rowNum + 1, sheet.getLastRowNum(), 1, true, false);
                                Row newRow = sheet.createRow(rowNum + 1);
                                newRow.setHeight(row.getHeight());

                                for (int j = 0; j < row.getLastCellNum(); j++) {
                                    Cell sourceCell = row.getCell(j);
                                    Cell newCell = newRow.createCell(j);

                                    if (sourceCell != null) {
                                        switch (sourceCell.getCellType()) {
                                            case STRING:
                                                newCell.setCellValue(sourceCell.getStringCellValue());
                                                break;
                                            case NUMERIC:
                                                newCell.setCellValue(sourceCell.getNumericCellValue());
                                                break;
                                            // Add more cases for other data types if needed
                                        }
                                    }
                                }
                            }
                            rowNum += copyCount; // Skip the inserted rows
                        }
                    }
                }
            }

            // Save the modified Excel file
            FileOutputStream fileOutputStream = new FileOutputStream("output_excel_file.xlsx");
            workbook.write(fileOutputStream);
            fileOutputStream.close();

            // Close the input stream and workbook
            fileInputStream.close();
            workbook.close();

            System.out.println("Rows copied and pasted successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
