package DataSheetFormatting;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;

//Remove mappings sheet if any empty cell is present in 2nd or 3rd column.


public class MappingSheetCheck {

    public static void main(String[] args) {
        // Specify the folder path where your Excel files are located
        String folderPath = "C:\\Users\\dell\\Desktop\\TaaS_Manual";

        // List all the Excel files in the folder
        File folder = new File(folderPath);
        File[] excelFiles = folder.listFiles((dir, name) -> name.endsWith(".xlsx"));

        if (excelFiles == null || excelFiles.length == 0) {
            System.out.println("No Excel files found in the specified folder.");
            return;
        }

        for (File file : excelFiles) {
            try {
                System.out.println("Processing file: " + file.getName());

                FileInputStream fis = new FileInputStream(file);
                XSSFWorkbook workbook = new XSSFWorkbook(fis);
                XSSFSheet sheet = workbook.getSheet("Mappings");

                if (sheet != null) {
                    boolean hasEmptyCell = checkForEmptyCells(sheet, 1) || checkForEmptyCells(sheet, 2);

                    if (hasEmptyCell) {
                        workbook.removeSheetAt(workbook.getSheetIndex(sheet));
                        System.out.println("Deleted sheet 'Mappings' from file: " + file.getName());

                        // Save the modified workbook back to the file
                        FileOutputStream fos = new FileOutputStream(file);
                        workbook.write(fos);
                        fos.close();
                    } else {
                        System.out.println("No empty cells found in 'Mappings' sheet of file: " + file.getName());
                    }

                    fis.close();
                } else {
                    System.out.println("Sheet 'Mappings' not found in file: " + file.getName());
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static boolean checkForEmptyCells(XSSFSheet sheet, int columnIndex) {
        Iterator<Row> rowIterator = sheet.iterator();
        boolean hasEmptyCell = false;

        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Cell cell = row.getCell(columnIndex);

            if (cell == null || cell.getCellType() == CellType.BLANK) {
                hasEmptyCell = true;
                break;
            }
        }

        return hasEmptyCell;
    }
}
