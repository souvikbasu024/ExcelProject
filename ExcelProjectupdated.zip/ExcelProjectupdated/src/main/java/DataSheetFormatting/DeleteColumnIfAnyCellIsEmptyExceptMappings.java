package DataSheetFormatting;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

//delete any empty cell present between 2 cell which have values

public class DeleteColumnIfAnyCellIsEmptyExceptMappings {
    public static void main(String[] args) {
        // Provide the path to the folder containing Excel files
        String folderPath = "C:\\Users\\dell\\Desktop\\TaaS_Manual";

        // List all the files in the folder
        File folder = new File(folderPath);
        File[] files = folder.listFiles();

        if (files != null) {
            for (File file : files) {
                if (file.isFile() && file.getName().endsWith(".xlsx")) {
                    try {
                        FileInputStream fis = new FileInputStream(file);
                        XSSFWorkbook workbook = new XSSFWorkbook(fis);

                        // Iterate over sheets in the workbook
                        for (int sheetIndex = 0; sheetIndex < workbook.getNumberOfSheets(); sheetIndex++) {
                            XSSFSheet sheet = workbook.getSheetAt(sheetIndex);

                            // Skip processing if the sheet name is "Mappings"
                            if (sheet.getSheetName().equalsIgnoreCase("Mappings")) {
                                continue;
                            }

                            // Iterate over each column
                            for (int colIndex = 0; colIndex <= sheet.getRow(0).getLastCellNum(); colIndex++) {
                                boolean hasEmptyCell = false;

                                // Iterate over each row in the column
                                for (int rowIndex = 0; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
                                    Row row = sheet.getRow(rowIndex);
                                    if (row != null) {
                                        Cell cell = row.getCell(colIndex);
                                        if (cell == null || cell.getCellType() == CellType.BLANK) {
                                            hasEmptyCell = true;
                                            break;
                                        }
                                    }
                                }

                                // If the column has any empty cell, delete it
                                if (hasEmptyCell) {
                                    sheet.setColumnHidden(colIndex, true);
                                }
                            }
                        }

                        fis.close();

                        // Save the modified workbook
                        FileOutputStream fos = new FileOutputStream(file);
                        workbook.write(fos);
                        fos.close();

                        System.out.println("Processed: " + file.getName());

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }
}
