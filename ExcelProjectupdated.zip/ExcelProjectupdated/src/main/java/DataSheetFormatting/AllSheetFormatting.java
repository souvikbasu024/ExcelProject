package DataSheetFormatting;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

//adds cell border , make font size 10 and style specific , make header bold , give color to header and make cell full size

public class AllSheetFormatting {

    public static void main(String[] args) {
        String folderPath = "C:\\Users\\dell\\Desktop\\TaaS_Manual"; // Replace with the path to your folder containing Excel files
        File folder = new File(folderPath);
        
        // List all Excel files in the folder
        File[] files = folder.listFiles((dir, name) -> name.endsWith(".xlsx"));
        
        if (files != null) {
            for (File file : files) {
                try {
                    if (file.length() > 0) {
                        formatExcelFile(file);
                        System.out.println("Formatting completed for file: " + file.getName());
                    } else {
                        System.err.println("Skipping empty file: " + file.getName());
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } else {
            System.err.println("Folder does not contain any Excel files.");
        }
    }

    private static void formatExcelFile(File file) throws IOException {
        FileInputStream fis = new FileInputStream(file);
        Workbook workbook = new XSSFWorkbook(fis);

        // Iterate through all sheets in the workbook
        for (int sheetIndex = 0; sheetIndex < workbook.getNumberOfSheets(); sheetIndex++) {
            Sheet sheet = workbook.getSheetAt(sheetIndex);

            CellStyle cellStyle = workbook.createCellStyle();
            cellStyle.setBorderLeft(BorderStyle.THIN);
            cellStyle.setBorderRight(BorderStyle.THIN);
            cellStyle.setBorderTop(BorderStyle.THIN);
            cellStyle.setBorderBottom(BorderStyle.THIN);
            cellStyle.setFont(createFont(workbook));
            cellStyle.setShrinkToFit(true);
            cellStyle.setWrapText(false);

            // Apply cell border and font size to all cells
            for (Row row : sheet) {
                for (Cell cell : row) {
                    cell.setCellStyle(cellStyle);
                }
            }

            // Apply full text width to all columns
            for (int i = 0; i < sheet.getRow(0).getLastCellNum(); i++) {
                sheet.autoSizeColumn(i);
            }

            // Format column headers
            Row headerRow = sheet.getRow(0);
            CellStyle headerCellStyle = workbook.createCellStyle();
            headerCellStyle.cloneStyleFrom(cellStyle);
            headerCellStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
            headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            Font headerFont = createFont(workbook);
            headerFont.setBold(true);
            headerCellStyle.setFont(headerFont);

            for (Cell cell : headerRow) {
                cell.setCellStyle(headerCellStyle);
            }
        }

        fis.close();

        // Write the formatted workbook back to the file
        FileOutputStream fos = new FileOutputStream(file);
        workbook.write(fos);
        fos.close();
    }

    private static Font createFont(Workbook workbook) {
        Font font = workbook.createFont();
        font.setFontName("Calibri");
        font.setFontHeightInPoints((short) 10);
        return font;
    }
}

