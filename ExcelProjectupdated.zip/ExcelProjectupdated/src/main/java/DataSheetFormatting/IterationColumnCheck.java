package DataSheetFormatting;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;


//checks if column name with present in excel file or not. if not then it adds the new column//
public class IterationColumnCheck {
    public static void main(String[] args) {
        // Define the folder containing Excel files
        String folderPath = "C:\\Users\\dell\\Desktop\\TaaS_Manual";

        // List all the files in the folder
        File folder = new File(folderPath);
        File[] files = folder.listFiles();

        if (files != null) {
            for (File file : files) {
                if (file.isFile() && file.getName().endsWith(".xlsx")) {
                    try {
                        FileInputStream fis = new FileInputStream(file);
                        XSSFWorkbook workbook = new XSSFWorkbook(fis);
                        XSSFSheet sheet = workbook.getSheetAt(0); // Assuming you want to modify the first sheet

                        // Check if "Iteration" column is present
                        boolean iterationColumnExists = false;
                        Row firstRow = sheet.getRow(0);
                        if (firstRow != null) {
                            for (Cell cell : firstRow) {
                                if (cell.getStringCellValue().equals("Iteration")) {
                                    iterationColumnExists = true;
                                    break;
                                }
                            }
                        }

                        if (!iterationColumnExists) {
                            // Insert "Iteration" column at the first position
                            for (Row row : sheet) {
                                row.shiftCellsRight(0, 1,0);
                                Cell cell = row.createCell(0);
                                cell.setCellValue("Iteration");
                            }

                            // Set the value in the newly created "Iteration" column to "1"
                            Cell headerCell = firstRow.createCell(0);
                            headerCell.setCellValue("Iteration");

                            for (int rowIndex = 1; rowIndex < sheet.getPhysicalNumberOfRows(); rowIndex++) {
                                Row dataRow = sheet.getRow(rowIndex);
                                if (dataRow != null) {
                                    Cell dataCell = dataRow.createCell(0);
                                    dataCell.setCellValue("1");
                                }
                            }
                        }

                        // Write changes back to the file
                        fis.close();
                        FileOutputStream fos = new FileOutputStream(file);
                        workbook.write(fos);
                        fos.close();

                        System.out.println("Processed file: " + file.getName());

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }
}
