package FileSearch;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;

import java.io.*;

public class Pertialreplace2 {
    public static void main(String[] args) {
        // Directory containing the Excel files
        String directoryPath = "C:\\Users\\dell\\Desktop\\New folder";

        // Value to search for and replacement value
        String searchValue = "My Client groups";
        String replacementValue = "My Client group";

        File directory = new File(directoryPath);

        if (directory.isDirectory()) {
            File[] files = directory.listFiles();

            if (files != null) {
                for (File file : files) {
                    if (file.isFile() && file.getName().endsWith(".xlsx")) {
                        try {
                            FileInputStream fis = new FileInputStream(file);
                            XSSFWorkbook workbook = new XSSFWorkbook(fis);
                            XSSFSheet sheet = workbook.getSheetAt(0);

                            boolean foundValue = false;

                            for (Row row : sheet) {
                                for (Cell cell : row) {
                                    if (cell.getCellType() == CellType.STRING) {
                                        String cellValue = cell.getStringCellValue();
                                        if (cellValue.contains(searchValue)) {
                                            cellValue = cellValue.replace(searchValue, replacementValue);
                                            cell.setCellValue(cellValue);
                                            foundValue = true;
                                        }
                                    }
                                }
                            }

                            fis.close();

                            if (foundValue) {
                                FileOutputStream fos = new FileOutputStream(file);
                                workbook.write(fos);
                                fos.close();
                                System.out.println("Replaced values in: " + file.getName());
                            } else {
                                System.out.println("Search value not found in: " + file.getName());
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }
    }
}
