package FileSearch;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;

import java.io.*;

public class PertialReplaceUpdated {
    public static void main(String[] args) {
        // Directory containing the Excel files
        String directoryPath = "C:\\Users\\dell\\Documents\\iss-oracle-cloud-erp\\src\\main\\resources\\Data";

        // Value to search for and replacement value
        String searchValue = "My client Groups";
        String replacementValue = "My client Group";

        File directory = new File(directoryPath);

        if (directory.isDirectory()) {
            File[] files = directory.listFiles();

            if (files != null) {
                for (File file : files) {
                    if (file.isFile() && file.getName().endsWith(".xlsx")) {
                        try {
                            FileInputStream fis = new FileInputStream(file);
                            XSSFWorkbook workbook = new XSSFWorkbook(fis);

                            boolean foundValue = false;

                            for (int sheetIndex = 0; sheetIndex < workbook.getNumberOfSheets(); sheetIndex++) {
                                XSSFSheet sheet = workbook.getSheetAt(sheetIndex);

                                for (Row row : sheet) {
                                    for (Cell cell : row) {
                                        if (cell.getCellType() == CellType.STRING) {
                                            String cellValue = cell.getStringCellValue();
                                            if (cellValue.contains(searchValue)) {
                                                cellValue = cellValue.replace(searchValue, replacementValue);
                                                cell.setCellValue(cellValue);
                                                foundValue = true;
                                            }
                                        }
                                    }
                                }
                            }

                            fis.close();

                            if (foundValue) {
                                FileOutputStream fos = new FileOutputStream(file);
                                workbook.write(fos);
                                fos.close();
                                System.out.println("Replaced values in: " + file.getName());
                            } else {
                                System.out.println("Search value not found in: " + file.getName() + ". Skipping the file.");
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }
    }
}
