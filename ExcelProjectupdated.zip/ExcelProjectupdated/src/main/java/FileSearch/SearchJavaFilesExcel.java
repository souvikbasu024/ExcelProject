package FileSearch;

import java.io.*;
import java.util.*;

import org.apache.commons.compress.archivers.dump.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class SearchJavaFilesExcel {
    public static void main(String[] args) throws InvalidFormatException {
        Scanner scanner = new Scanner(System.in);

        // Step 1: Take input of the folder path
        System.out.print("Enter the folder path: ");
        String folderPath = scanner.nextLine();

        // Step 2: Take input of an Excel file containing search values
        System.out.print("Enter the path to the Excel file containing search values: ");
        String excelFilePath = scanner.nextLine();

        // Load the search values from the Excel file
        List<String> searchValues = loadSearchValuesFromExcel(excelFilePath);

        // Create a workbook and sheet for Excel output
        Workbook workbook = new XSSFWorkbook();
        Sheet resultsSheet = workbook.createSheet("Search Results");
        int rowIndex = 0;

        // Iterate through the search values and search for each one
        for (String searchValue : searchValues) {
            // Call the method to search for the value in .java files
            searchInJavaFiles(new File(folderPath), searchValue, resultsSheet, rowIndex);
            rowIndex++;
        }

        // Save the Excel file with results
        try (FileOutputStream outputStream = new FileOutputStream("SearchResults.xlsx")) {
            workbook.write(outputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }

        scanner.close();
    }

    public static List<String> loadSearchValuesFromExcel(String excelFilePath) throws InvalidFormatException {
        List<String> searchValues = new ArrayList<>();
        try (FileInputStream inputStream = new FileInputStream(excelFilePath);
             Workbook workbook = WorkbookFactory.create(inputStream)) {
            Sheet sheet = workbook.getSheetAt(0); // Assuming search values are in the first sheet

            for (Row row : sheet) {
                Cell cell = row.getCell(0); // Assuming the search values are in the first column
                if (cell != null) {
                    searchValues.add(cell.getStringCellValue());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return searchValues;
    }

    public static void searchInJavaFiles(File directory, String searchValue, Sheet resultsSheet, int rowIndex) {
        if (directory.isDirectory()) {
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (file.isDirectory()) {
                        searchInJavaFiles(file, searchValue, resultsSheet, rowIndex);
                    } else if (file.isFile() && file.getName().endsWith(".java")) {
                        if (containsValue(file, searchValue)) {
                            Row row = resultsSheet.createRow(rowIndex);
                            Cell cell = row.createCell(0);
                            cell.setCellValue(searchValue);
                            cell = row.createCell(1);
                            cell.setCellValue(file.getName());
                            rowIndex++;
                        }
                    }
                }
            }
        }
    }

    public static boolean containsValue(File file, String searchValue) {
        try (Scanner fileScanner = new Scanner(file)) {
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                if (line.contains(searchValue)) {
                    return true;
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return false;
    }
}
