package FileSearch;

import java.io.*;
import java.util.*;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class PrintOnlyoneValue {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		// Step 1: Take input of the folder path
		System.out.print("Enter the folder path: ");
		String folderPath = scanner.nextLine();

		// Step 2: Take input of an Excel file containing search values
		System.out.print("Enter the path to the Excel file containing search values: ");
		String excelFilePath = scanner.nextLine();

		System.out.print("Enter the output file name ");
		String outputfilename = scanner.nextLine();

		// Load the search values from the Excel file
		List<String> searchValues = loadSearchValuesFromExcel(excelFilePath);

		// Create a workbook and sheet for Excel output
		Workbook workbook = new XSSFWorkbook();
		Sheet resultsSheet = workbook.createSheet("Search Result");

		// Set up the header row
		Row headerRow = resultsSheet.createRow(0);
		Cell headerCell = headerRow.createCell(0);
		headerCell.setCellValue("Search Value");
		headerCell = headerRow.createCell(1);
		headerCell.setCellValue("File Name");

		// Iterate through the search values and search for each one
		int rowIndex = 1; // Start from the second row (1-based index)
		for (String searchValue : searchValues) {
			// Call the method to search for the value in .java files
			String resultFileName = searchInJavaFiles(new File(folderPath), searchValue);

			// Create a new row for the result
			Row row = resultsSheet.createRow(rowIndex);
			Cell cell = row.createCell(0);
			cell.setCellValue(searchValue);
			cell = row.createCell(1);
			cell.setCellValue(resultFileName);
			rowIndex++;
		}

		// Save the Excel file with results
		try (FileOutputStream outputStream = new FileOutputStream(outputfilename + ".xlsx")) {
			workbook.write(outputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}

		scanner.close();
		
		System.out.println("-------------------------Complete---------------------"+"\n"+"Result is saved in"+"  " +outputfilename + ".xlsx");
	}

	public static List<String> loadSearchValuesFromExcel(String excelFilePath) {
		List<String> searchValues = new ArrayList<>();
		try (FileInputStream inputStream = new FileInputStream(excelFilePath);
				Workbook workbook = WorkbookFactory.create(inputStream)) {
			Sheet sheet = workbook.getSheetAt(0); // Assuming search values are in the first sheet

			for (Row row : sheet) {
				Cell cell = row.getCell(0); // Assuming the search values are in the first column
				if (cell != null) {
					searchValues.add(cell.getStringCellValue());
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return searchValues;
	}

	public static String searchInJavaFiles(File directory, String searchValue) {
		if (directory.isDirectory()) {
			File[] files = directory.listFiles();
			if (files != null) {
				for (File file : files) {
					if (file.isDirectory()) {
						String resultFileName = searchInJavaFiles(file, searchValue);
						if (resultFileName != null) {
							return resultFileName;
						}
					} else if (file.isFile() && file.getName().endsWith(".java")) {
						if (containsValue(file, searchValue)) {
							return file.getName();

						}
						System.out.println("Processing......");
					}
				}

			}
			
		}
		
		return null; // Return null if search value not found in any file
	}

	public static boolean containsValue(File file, String searchValue) {
		try (Scanner fileScanner = new Scanner(file)) {
			while (fileScanner.hasNextLine()) {
				String line = fileScanner.nextLine();
				if (line.contains(searchValue)) {
					return true;
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return false;
	}

}
