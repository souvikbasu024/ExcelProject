package FileSearch;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class GtdIterationSeparation {

    public static void main(String[] args) {
        String inputFilePath = "C:\\Users\\dell\\Desktop\\New folder\\GTD_HR_01_HR_Hire_Employee.xlsx"; // Replace with your input file path
        try (FileInputStream fis = new FileInputStream(inputFilePath);
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheetAt(0); // Assuming the data is in the first sheet
            Row headerRow = sheet.getRow(0); // Get the header row

            for (int i = 1; i < sheet.getPhysicalNumberOfRows(); i++) { // Start from the second row
                Row dataRow = sheet.getRow(i);
                if (dataRow != null) {
                    Workbook newWorkbook = new XSSFWorkbook();
                    Sheet newSheet = newWorkbook.createSheet();
                    
                    // Copy the header row to the new sheet
                    Row newHeaderRow = newSheet.createRow(0);
                    for (int j = 0; j < headerRow.getPhysicalNumberOfCells(); j++) {
                        Cell headerCell = headerRow.getCell(j);
                        if (headerCell != null) {
                            Cell newHeaderCell = newHeaderRow.createCell(j, headerCell.getCellType());
                            newHeaderCell.setCellValue(getCellValueAsString(headerCell));
                        }
                    }
                    
                    // Copy the data row to the new sheet
                    Row newDataRow = newSheet.createRow(1);
                    for (int j = 0; j < dataRow.getPhysicalNumberOfCells(); j++) {
                        Cell dataCell = dataRow.getCell(j);
                        if (dataCell != null) {
                            Cell newDataCell = newDataRow.createCell(j, dataCell.getCellType());
                            newDataCell.setCellValue(getCellValueAsString(dataCell));
                        }
                    }

                    String outputFileName = "output" + i + ".xlsx";
                    try (FileOutputStream fos = new FileOutputStream(outputFileName)) {
                        newWorkbook.write(fos);
                    }
                }
            }

            System.out.println("Excel files created successfully!");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String getCellValueAsString(Cell cell) {
        if (cell.getCellType() == CellType.STRING) {
            return cell.getStringCellValue();
        } else if (cell.getCellType() == CellType.NUMERIC) {
            return String.valueOf(cell.getNumericCellValue());
        } else if (cell.getCellType() == CellType.BOOLEAN) {
            return String.valueOf(cell.getBooleanCellValue());
        } else {
            return "";
        }
    }
}
