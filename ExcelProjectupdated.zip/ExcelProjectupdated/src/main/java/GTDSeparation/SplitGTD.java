package GTDSeparation;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class SplitGTD {


    public static void main(String[] args) {
        String inputFilePath = "C:\\Users\\souvi\\OneDrive\\Documents\\aps-oracle-cloud-erp\\src\\main\\resources\\Data\\GTD_FA_01_SetA_1_GTD_FA_Prepare_Source_Lines_For_Assets.xlsx"; // Replace with your input file path
        try (FileInputStream fis = new FileInputStream(inputFilePath);
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet firstSheet = workbook.getSheetAt(0); // Assuming the data is in the first sheet

            for (int i = 1; i < firstSheet.getPhysicalNumberOfRows(); i++) { // Start from the second row
                Row dataRow = firstSheet.getRow(i);
                if (dataRow != null) {
                    Workbook newWorkbook = new XSSFWorkbook();
                    Sheet newSheet = newWorkbook.createSheet(firstSheet.getSheetName());

                    // Copy the header row to the new sheet with formatting
                    copyRowWithFormatting(workbook, newWorkbook, firstSheet.getRow(0), newSheet.createRow(0));

                    // Copy the data row to the new sheet with formatting
                    copyRowWithFormatting(workbook, newWorkbook, dataRow, newSheet.createRow(1));

                    // Copy the remaining sheets to the new workbook
                    Iterator<Sheet> sheetIterator = workbook.sheetIterator();
                    sheetIterator.next(); // Skip the first sheet (already added)
                    while (sheetIterator.hasNext()) {
                        Sheet sourceSheet = sheetIterator.next();
                        Sheet newSheetCopy = newWorkbook.createSheet(sourceSheet.getSheetName());
                        for (int j = 0; j <= sourceSheet.getLastRowNum(); j++) {
                            Row sourceRow = sourceSheet.getRow(j);
                            if (sourceRow != null) {
                                Row destRow = newSheetCopy.createRow(j);
                                for (int k = 0; k < sourceRow.getPhysicalNumberOfCells(); k++) {
                                    Cell sourceCell = sourceRow.getCell(k);
                                    if (sourceCell != null) {
                                        Cell destCell = destRow.createCell(k, sourceCell.getCellType());
                                        if (sourceCell.getCellType() == CellType.NUMERIC) {
                                            if (DateUtil.isCellDateFormatted(sourceCell)) {
                                                destCell.setCellValue(sourceCell.getDateCellValue());
                                            } else {
                                                destCell.setCellValue((int) sourceCell.getNumericCellValue());
                                            }
                                        } else {
                                            destCell.setCellValue(getCellValueAsString(sourceCell));
                                        }

                                        CellStyle sourceStyle = sourceCell.getCellStyle();
                                        CellStyle destStyle = newWorkbook.createCellStyle();
                                        destStyle.cloneStyleFrom(sourceStyle);
                                        destCell.setCellStyle(destStyle);
                                    }
                                }
                            }
                        }
                    }

                    String inputFileName = inputFilePath.substring(inputFilePath.lastIndexOf("/") + 1);
                    int index = "inputFileName".indexOf('_', 2);
                    String outputFileName = inputFileName.substring(0, inputFileName.lastIndexOf(".")) + "_" + i + ".xlsx";
                    //String outputFileName = inputFileName.substring(0, index)+inputFileName.substring(index+1, inputFileName.lastIndexOf(".")) + "_" + i + ".xlsx";
                    //String outputFileName ="GTD_HR_01_SetA1"+"_"+i+".xlsx";
                    try (FileOutputStream fos = new FileOutputStream(outputFileName)) {
                        newWorkbook.write(fos);
                    }
                }
            }

            System.out.println("Excel files created successfully!");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void copyRowWithFormatting(Workbook sourceWorkbook, Workbook destWorkbook, Row sourceRow, Row destRow) {
        for (int j = 0; j < sourceRow.getPhysicalNumberOfCells(); j++) {
            Cell sourceCell = sourceRow.getCell(j);
            if (sourceCell != null) {
                Cell destCell = destRow.createCell(j, sourceCell.getCellType());
                if (sourceCell.getCellType() == CellType.NUMERIC) {
                    if (DateUtil.isCellDateFormatted(sourceCell)) {
                        destCell.setCellValue(sourceCell.getDateCellValue());
                    } else {
                        destCell.setCellValue((int) sourceCell.getNumericCellValue());
                    }
                } else {
                    destCell.setCellValue(getCellValueAsString(sourceCell));
                }

                CellStyle sourceStyle = sourceCell.getCellStyle();
                CellStyle destStyle = destWorkbook.createCellStyle();
                destStyle.cloneStyleFrom(sourceStyle);
                destCell.setCellStyle(destStyle);
            }
        }
    }

    private static String getCellValueAsString(Cell cell) {
        if (cell.getCellType() == CellType.STRING) {
            return cell.getStringCellValue();
        } else if (cell.getCellType() == CellType.BOOLEAN) {
            return String.valueOf(cell.getBooleanCellValue());
        } else {
            return "";
        }
    }

}
