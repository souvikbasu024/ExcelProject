package souvik;

import java.io.*;
import java.util.*;

public class filesearch {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Step 1: Take input of the folder path
        System.out.print("Enter the folder path: ");
        String folderPath = scanner.nextLine();
        
        // Step 2: Take input of a value to search
        System.out.print("Enter the value to search: ");
        String searchValue = scanner.nextLine();
        
        // Call the method to search for the value in .java files
        searchInJavaFiles(new File(folderPath), searchValue);
        
        scanner.close();
    }
    
    public static void searchInJavaFiles(File directory, String searchValue) {
        if (directory.isDirectory()) {
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (file.isDirectory()) {
                        searchInJavaFiles(file, searchValue);
                    } else if (file.isFile() && file.getName().endsWith(".java")) {
                        if (containsValue(file, searchValue)) {
                            System.out.println("Found in file: " + file.getName());
                        }
                    }
                }
            }
        }
    }
    
    public static boolean containsValue(File file, String searchValue) {
        try (Scanner fileScanner = new Scanner(file)) {
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                if (line.contains(searchValue)) {
                    return true;
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return false;
    }
}
