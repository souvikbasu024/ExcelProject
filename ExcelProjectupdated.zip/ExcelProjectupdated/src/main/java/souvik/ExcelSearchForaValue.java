package souvik;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

public class ExcelSearchForaValue {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the folder path containing Excel files: ");
        String folderPath = scanner.nextLine();

        System.out.print("Enter the cell value to search: ");
        String searchValue = scanner.nextLine();

        File folder = new File(folderPath);
        File[] excelFiles = folder.listFiles((dir, name) -> name.endsWith(".xlsx"));

        if (excelFiles != null) {
            for (File file : excelFiles) {
                try (FileInputStream fis = new FileInputStream(file);
                     Workbook workbook = new XSSFWorkbook(fis)) {

                    for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
                        Sheet sheet = workbook.getSheetAt(i);
                        for (Row row : sheet) {
                            for (Cell cell : row) {
                                if (cell.getCellType() == CellType.STRING) {
                                    String cellValue = cell.getStringCellValue();
                                    if (cellValue.equalsIgnoreCase(searchValue)) {
                                        System.out.println("Found in: " + file.getName());
                                    }
                                }
                            }
                        }
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
