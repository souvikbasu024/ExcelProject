import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class SearchandcopyInMasterDriverFinal {
    public static void main(String[] args) {
        try {
        	 String excelFilePath = "C:\\Users\\souvi\\OneDrive\\Documents\\aps-oracle-cloud-erp\\src\\main\\resources\\Data\\ACT_MasterDriver.xlsx"; // Replace with your Excel file path
             String searchValue = "GTD_FA_01"; // Replace with the value you want to search for
             int copyCount = 7; // Number of times to copy the found rows

            // Define prefixes for TestID and Batch File Name
            String testIdPrefix = "_SetA_";
            String batchFileNamePrefix = "_";

            FileInputStream inputStream = new FileInputStream(new File(excelFilePath));
            Workbook workbook = new XSSFWorkbook(inputStream);

            // Iterate through the first two sheets
            for (int sheetIndex = 0; sheetIndex < 2; sheetIndex++) {
                Sheet sheet = workbook.getSheetAt(sheetIndex);

                int rowCount = sheet.getPhysicalNumberOfRows();

                // Find the column indices of "TestID" and "Batch File Name"
                int testIdColumnIndex = -1; // Initialize to -1 (not found)
                int batchFileNameColumnIndex = -1; // Initialize to -1 (not found)
                Row headerRow = sheet.getRow(0);
                if (headerRow != null) {
                    for (int cellIndex = 0; cellIndex < headerRow.getLastCellNum(); cellIndex++) {
                        Cell headerCell = headerRow.getCell(cellIndex);
                        if (headerCell != null && headerCell.getCellType() == CellType.STRING) {
                            String headerCellValue = headerCell.getStringCellValue();
                            if (headerCellValue.equals("TestID")) {
                                testIdColumnIndex = cellIndex;
                            } else if (headerCellValue.equals("Batch File Name")) {
                                batchFileNameColumnIndex = cellIndex;
                            }
                        }
                    }
                }

                // Create a CellStyle to preserve formatting
                CellStyle cellStyle = sheet.getRow(0).getCell(0).getCellStyle();

                // Iterate through rows to find the search value
                for (int rowIndex = 0; rowIndex < rowCount; rowIndex++) {
                    Row row = sheet.getRow(rowIndex);
                    if (row != null) {
                        Cell cell = row.getCell(0); // Assuming you want to search in the first column (column 0)

                        if (cell != null && cell.getCellType() == CellType.STRING && cell.getStringCellValue().equals(searchValue)) {
                            // Found the search value, copy and paste the row multiple times
                            for (int i = 0; i < copyCount; i++) {
                                Row newRow = sheet.createRow(rowIndex + i + 1); // Create a new row below the found row

                                // Copy cell values and formatting
                                for (int cellIndex = 0; cellIndex < row.getLastCellNum(); cellIndex++) {
                                    Cell originalCell = row.getCell(cellIndex);
                                    Cell newCell = newRow.createCell(cellIndex);
                                    if (originalCell != null) {
                                        switch (originalCell.getCellType()) {
                                            case STRING:
                                                newCell.setCellValue(originalCell.getStringCellValue());
                                                if (cellIndex == testIdColumnIndex) {
                                                    newCell.setCellValue(originalCell.getStringCellValue()+ testIdPrefix+ (i + 1)); // Append the count with prefix
                                                } else if (cellIndex == batchFileNameColumnIndex) {
                                                    newCell.setCellValue(originalCell.getStringCellValue() +batchFileNamePrefix+ (i + 1)); // Append the count with prefix
                                                }
                                                break;
                                            case NUMERIC:
                                                newCell.setCellValue(originalCell.getNumericCellValue());
                                                break;
                                            // Add more cases for other cell types if needed
                                        }
                                        // Copy cell style
                                        newCell.setCellStyle(cellStyle);
                                    }
                                }
                            }
                            break; // Stop searching after finding the first occurrence
                        }
                    }
                }
            }

            // Save the changes back to the Excel file
            FileOutputStream outputStream = new FileOutputStream(excelFilePath);
            workbook.write(outputStream);
            workbook.close();
            outputStream.close();

            System.out.println("Search and copy operation completed.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
