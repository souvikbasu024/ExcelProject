package Final;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.FilenameFilter;

public class Deletecellvalue {
    public static void main(String[] args) {
        // Take input of the folder path and column header name
        String folderPath = "C:\\Users\\dell\\Documents\\iss-oracle-cloud-erp\\src\\main\\resources\\Data";
        String columnHeader = "Souvik";

        File folder = new File(folderPath);

        if (!folder.isDirectory()) {
            System.out.println("Invalid folder path.");
            return;
        }

        // Define a custom FilenameFilter to select only .xlsx files
        FilenameFilter xlsxFilter = new FilenameFilter() {
            @Override
            public boolean accept(File dir, String name) {
                return name.toLowerCase().endsWith(".xlsx");
            }
        };

        File[] files = folder.listFiles(xlsxFilter);

        for (File file : files) {
            try {
                FileInputStream fis = new FileInputStream(file);
                XSSFWorkbook workbook = new XSSFWorkbook(fis);

                boolean foundHeader = false;

                for (int sheetIndex = 0; sheetIndex < workbook.getNumberOfSheets(); sheetIndex++) {
                    Sheet sheet = workbook.getSheetAt(sheetIndex);
                    Row headerRow = sheet.getRow(0);

                    if (headerRow != null) {
                        for (int cellIndex = headerRow.getFirstCellNum(); cellIndex < headerRow.getLastCellNum(); cellIndex++) {
                            Cell headerCell = headerRow.getCell(cellIndex);

                            if (headerCell != null && columnHeader.equals(headerCell.getStringCellValue())) {
                                foundHeader = true;

                                // Delete values of the specified column in the current sheet
                                for (int rowIndex = 1; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
                                    Row dataRow = sheet.getRow(rowIndex);
                                    if (dataRow != null) {
                                        Cell cellToDelete = dataRow.getCell(cellIndex);
                                        if (cellToDelete != null) {
                                            // Set the cell value to an empty string
                                            cellToDelete.setCellValue("");
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                fis.close();

                // Save the changes back to the same file only if the header was found
                if (foundHeader) {
                    FileOutputStream fos = new FileOutputStream(file);
                    workbook.write(fos);
                    fos.close();
                    System.out.println("Processed file: " + file.getName());
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
