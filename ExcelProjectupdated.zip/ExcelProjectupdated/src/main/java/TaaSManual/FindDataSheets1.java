package TaaSManual;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class FindDataSheets1 {
    public static void main(String[] args) {
        String excelFilePath = "C:\\Users\\dell\\Desktop\\TaaS_Manual\\ACT_MasterDriver.xlsx"; // Replace with the path to your Excel file
        String folderPath = "C:\\Users\\dell\\Downloads\\AST\\aps-oracle-cloud-erp\\src\\main\\resources\\Data"; // Replace with the path to your source folder
        String destinationPath = "C:\\Users\\dell\\Desktop\\TaaS_Manual"; // Replace with the path to your destination folder

        try {
            FileInputStream excelFile = new FileInputStream(new File(excelFilePath));
            Workbook workbook = new XSSFWorkbook(excelFile);
            Sheet sheet = workbook.getSheetAt(0);

            for (Row row : sheet) {
                if (row.getCell(0) != null) {
                    String fileNameToSearch = row.getCell(0).getStringCellValue();
                    Path sourceFilePath = Paths.get(folderPath, fileNameToSearch);
                    Path destinationFilePath = Paths.get(destinationPath, fileNameToSearch);

                    if (Files.exists(sourceFilePath)) {
                        Files.createDirectories(destinationFilePath.getParent());
                        Files.copy(sourceFilePath, destinationFilePath, StandardCopyOption.REPLACE_EXISTING);
                        System.out.println("File '" + fileNameToSearch + "' copied successfully.");
                    } else {
                        System.out.println("File '" + fileNameToSearch + "' not found in the source folder.");
                    }
                }
            }

            workbook.close();
            excelFile.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}