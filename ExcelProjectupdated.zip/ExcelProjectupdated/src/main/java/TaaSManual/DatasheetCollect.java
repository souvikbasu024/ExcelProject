package TaaSManual;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class DatasheetCollect {
	public static void main(String[] args) throws IOException {
	
			// Load the input Excel files
			FileInputStream inputWorkbook1 = new FileInputStream("C:\\TaaSManualProject\\Sample_Procure_List.xlsx");

			// Create a workbook for the first input file
			Workbook workbook1 = new XSSFWorkbook(inputWorkbook1);

			// Get the sheet you want to work with from the first input file
			Sheet sheet1 = workbook1.getSheetAt(0);

			// Create a new workbook for the results
			Workbook resultWorkbook = new XSSFWorkbook();

			
			
            

			// List to store matching "TestID" values and corresponding fetched values
			List<String> matchingTestIDs = new ArrayList<>();
			List<String> fetchedValues = new ArrayList<>();

			// List to store matching rows in the second input file's next sheet
			List<Row> matchingRowsInNextSheet = new ArrayList<>();

			// Iterate over the rows in the first sheet (input data)
			for (Row row1 : sheet1) {
				// Get the value from the next respective column (e.g., column 1)
				Cell nextColumnCell = row1.getCell(1); // Adjust the column index as needed
				String fetchedValue = "";
				if (nextColumnCell != null && nextColumnCell.getCellType() == CellType.STRING) {
					fetchedValue = nextColumnCell.getStringCellValue();
				}

				// Iterate over the rows in the second sheet (search target)
				FileInputStream inputWorkbook2 = new FileInputStream("C:\\TaaSManualProject\\Grep\\MasterDriver\\ACT_MasterDriver_" + fetchedValue + ".xlsx");
				Workbook workbook2 = new XSSFWorkbook(inputWorkbook2);
				Sheet sheet2 = workbook2.getSheetAt(0); // Assuming it's the first sheet of the dynamically generated
														// file

				for (Row row2 : sheet2) {
					// Check if any cell in the current row2 partially matches any cell in the
					// current row1
					boolean foundMatch = false;
					for (Cell cell1 : row1) {
						for (Cell cell2 : row2) {
							if (cell1.getCellType() == CellType.STRING && cell2.getCellType() == CellType.STRING) {
								String value1 = cell1.getStringCellValue().toLowerCase();
								String value2 = cell2.getStringCellValue().toLowerCase();
								if (value2.contains(value1)) {
									foundMatch = true;
									break;
								}
							}

						}
						if (foundMatch) {
							break;
						}
					}
					// If a partial match is found, store the "TestID" value, fetched value, and
					// matching row
					if (foundMatch) {
						Cell testIdCell = row2.getCell(0); // Assuming "TestID" is in the first column of the second
															// sheet
						if (testIdCell != null && testIdCell.getCellType() == CellType.STRING) {
							String testID = testIdCell.getStringCellValue();
							matchingTestIDs.add(testID);
							fetchedValues.add(fetchedValue);
							matchingRowsInNextSheet.add(row2);
							break; // Assuming you want to find only the first matching row in the second sheet
						}
					}
				}

				// Close the input stream for the dynamically generated input file
				try {
					inputWorkbook2.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			

			// Iterate through the matching rows from the second input file and copy them to
			// the second resulting sheet
			int rowNum2 = 0;
			for (int i = 0; i < matchingTestIDs.size(); i++) {
				String testID = matchingTestIDs.get(i);
				String fetchedValue = fetchedValues.get(i);


                String partialFileNameToSearch = testID;
                Path sourceFolderPath = Paths.get("C:\\TaaSManualProject\\Grep\\Current Repo\\"+fetchedValue+"\\src\\main\\resources\\Data");
                try (DirectoryStream<Path> stream = Files.newDirectoryStream(sourceFolderPath)) {
                    for (Path sourceFilePath : stream) {
                        String fileName = sourceFilePath.getFileName().toString();
                        if (fileName.startsWith(partialFileNameToSearch)) {
                            Path destinationFilePath = Paths.get("C:\\TaaSManualProject\\Temp\\New folder", fileName);
                            Files.createDirectories(destinationFilePath.getParent());
                            Files.copy(sourceFilePath, destinationFilePath, StandardCopyOption.REPLACE_EXISTING);
                            System.out.println("File '" + fileName + "' copied successfully.");
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            

				
			}
			}
}

			
					

	
		