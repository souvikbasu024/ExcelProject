package TaaSManual;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Finddatasheet2 {
    public static void main(String[] args) {
    	String excelFilePath = "C:\\TaaSManualProject\\Temp\\Name22222.xlsx"; // Replace with the path to your Excel file
        String folderPath = "C:\\TaaSManualProject\\Grep\\Current Repo"; // Replace with the path to your source folder
        String destinationPath = "C:\\TaaSManualProject\\Temp\\New folder"; // Replace with the path to your destination folder


        try {
            FileInputStream excelFile = new FileInputStream(new File(excelFilePath));
            Workbook workbook = new XSSFWorkbook(excelFile);
            Sheet sheet = workbook.getSheetAt(0);

            for (Row row : sheet) {
                if (row.getCell(0) != null) {
                    String partialFileNameToSearch = row.getCell(0).getStringCellValue();
                    Path sourceFolderPath = Paths.get(folderPath);
                    try (DirectoryStream<Path> stream = Files.newDirectoryStream(sourceFolderPath)) {
                        for (Path sourceFilePath : stream) {
                            String fileName = sourceFilePath.getFileName().toString();
                            if (fileName.startsWith(partialFileNameToSearch)) {
                                Path destinationFilePath = Paths.get(destinationPath, fileName);
                                Files.createDirectories(destinationFilePath.getParent());
                                Files.copy(sourceFilePath, destinationFilePath, StandardCopyOption.REPLACE_EXISTING);
                                System.out.println("File '" + fileName + "' copied successfully.");
                            }
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            workbook.close();
            excelFile.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
