import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Test4 {
    public static void main(String[] args) {
        try {
            // Load the input Excel files
            FileInputStream inputWorkbook1 = new FileInputStream("C:\\TaaS Manual Project\\Sample_Procure_List.xlsx");

            // Create workbooks
            Workbook workbook1 = new XSSFWorkbook(inputWorkbook1);

            // Get the sheets you want to work with (assuming it is the first sheet in the first workbook)
            Sheet sheet1 = workbook1.getSheetAt(0);

            // Create a new workbook for the results
            Workbook resultWorkbook = new XSSFWorkbook();

            // Create a resulting sheet for the search results
            Sheet resultSheet = resultWorkbook.createSheet("Result");

            // Copy column headers from the first sheet to the result sheet
            Row headerRow = resultSheet.createRow(0);
            Row firstSheetHeader = sheet1.getRow(0);
            for (int i = 0; i < firstSheetHeader.getLastCellNum(); i++) {
                Cell headerCell = headerRow.createCell(i);
                Cell firstSheetHeaderCell = firstSheetHeader.getCell(i);
                headerCell.setCellValue(firstSheetHeaderCell.getStringCellValue());

                // Copy cell formatting
                CellStyle headerCellStyle = resultWorkbook.createCellStyle();
                headerCellStyle.cloneStyleFrom(firstSheetHeaderCell.getCellStyle());
                headerCell.setCellStyle(headerCellStyle);
            }

            // List to store matching "TestID" values
            List<String> matchingTestIDs = new ArrayList<>();

            // List to store matching rows
            List<Row> matchingRows = new ArrayList<>();

            // Iterate over the rows in the first sheet (input data)
            for (Row row1 : sheet1) {
                // Get the value in the next column (assuming it is the second column)
                Cell nextColumnCell = row1.getCell(1); // Change the index as needed
                if (nextColumnCell != null && nextColumnCell.getCellType() == CellType.STRING) {
                    String nextColumnValue = nextColumnCell.getStringCellValue();
                    String searchValue = "C:\\TaaS Manual Project\\Grep\\MasterDriver\\ACT_MasterDriver_" + nextColumnValue.toLowerCase(); // Modify the prefix as needed

                    // Iterate over the rows in the same sheet (search target)
                    for (Row row2 : sheet1) {
                        // Check if any cell in the current row2 partially matches the search value
                        boolean foundMatch = false;
                        for (Cell cell2 : row2) {
                            if (cell2.getCellType() == CellType.STRING) {
                                String value2 = cell2.getStringCellValue().toLowerCase();
                                if (value2.contains(searchValue)) {
                                    foundMatch = true;
                                    break;
                                }
                            }
                            // Add handling for other cell types as needed
                        }
                        // If a partial match is found, store the "TestID" value
                        if (foundMatch) {
                            Cell testIdCell = row2.getCell(0); // Assuming "TestID" is in the first column
                            if (testIdCell != null && testIdCell.getCellType() == CellType.STRING) {
                                String testID = testIdCell.getStringCellValue();
                                matchingTestIDs.add(testID);
                                matchingRows.add(row2);
                                break; // Assuming you want to find only the first matching row
                            }
                        }
                    }
                }
            }

            // Copy matching rows to the result sheet
            int rowNum = 1;
            for (Row matchingRow : matchingRows) {
                Row newRow = resultSheet.createRow(rowNum++);
                Iterator<Cell> cellIterator = matchingRow.cellIterator();
                int cellNum = 0;
                while (cellIterator.hasNext()) {
                    Cell cell = cellIterator.next();
                    Cell newCell = newRow.createCell(cellNum++);
                    switch (cell.getCellType()) {
                        case STRING:
                            newCell.setCellValue(cell.getStringCellValue());
                            break;
                        case NUMERIC:
                            newCell.setCellValue(cell.getNumericCellValue());
                            break;
                        // Handle other cell types as needed
                    }

                    // Copy cell formatting
                    CellStyle cellStyle = resultWorkbook.createCellStyle();
                    cellStyle.cloneStyleFrom(cell.getCellStyle());
                    newCell.setCellStyle(cellStyle);
                }
            }

            // Specify the folder path and custom file name for the output file
            String outputPath = "C:\\TaaS Manual Project\\Temp"; // Replace with your folder path
            String customFileName = "customFileName.xlsx"; // Replace with your custom file name

            // Save the result workbook to the output folder
            File outputFile = new File(outputPath, customFileName);
            FileOutputStream fileOutputStream = new FileOutputStream(outputFile);
            resultWorkbook.write(fileOutputStream);
            fileOutputStream.close();

            // Close input streams
            inputWorkbook1.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
